@echo off
title CVD Heart Disease Dashboard
color 0A
cls

echo.
echo  ============================================
echo    HEART DISEASE DASHBOARD — Auto Setup
echo  ============================================
echo.

:: Check if Python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo  [ERROR] Python installed nahi hai!
    echo.
    echo  Python install karo:
    echo  https://www.python.org/downloads/
    echo  (Install karte waqt "Add to PATH" zaroor tick karo)
    echo.
    pause
    exit
)

echo  [1/3] Python mil gaya ✓
echo.

:: Install libraries
echo  [2/3] Libraries install ho rahi hain (2-3 minute lagenge)...
echo        Pehli baar thoda time lagta hai, dobara fast hoga.
echo.
pip install streamlit pandas numpy matplotlib seaborn scikit-learn xgboost lightgbm catboost imbalanced-learn --quiet --disable-pip-version-check

echo.
echo  [3/3] Libraries ready ✓
echo.

:: Check if pkl files exist
if not exist "results.pkl" (
    echo  [WARNING] results.pkl nahi mili!
    echo  results.pkl aur processed_data.pkl is folder mein rakhein.
    echo  (Colab se download ki thi woh dono files)
    echo.
    pause
)

if not exist "processed_data.pkl" (
    echo  [WARNING] processed_data.pkl nahi mili!
    echo  processed_data.pkl is folder mein rakhein.
    echo.
    pause
)

:: Launch dashboard
echo  ============================================
echo   Dashboard khul raha hai browser mein...
echo   (Kuch seconds wait karo)
echo  ============================================
echo.
echo   Band karna ho to is window mein Ctrl+C dabao
echo.

streamlit run dashboard.py --server.headless false

pause
